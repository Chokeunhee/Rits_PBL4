var searchData=
[
  ['projectordist_92',['projectorDist',['../class_config_reader_1_1_config_reader.html#a455afeda58ceaea5392e3c3876fde901',1,'ConfigReader::ConfigReader']]],
  ['projetedimgwidth_93',['projetedImgWidth',['../class_config_reader_1_1_config_reader.html#ae5ea6f53d38e9366011f6f78c323ca32',1,'ConfigReader::ConfigReader']]]
];
