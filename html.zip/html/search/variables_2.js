var searchData=
[
  ['gamma_84',['gamma',['../class_config_reader_1_1_config_reader.html#a727b4eaf45b1e983d807f6edcbb13c80',1,'ConfigReader::ConfigReader']]]
];
