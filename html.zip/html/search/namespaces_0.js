var searchData=
[
  ['configreader_52',['ConfigReader',['../namespace_config_reader.html',1,'']]]
];
