var searchData=
[
  ['blendingfactor_1',['blendingFactor',['../class_config_reader_1_1_config_reader.html#ac697dbb215cf9c04dffe7db792688b2e',1,'ConfigReader::ConfigReader']]],
  ['blendmask_2',['blendMask',['../class_image_processor_1_1_image_processor.html#a907cef9b4e43081eb7bc2ba600419df4',1,'ImageProcessor::ImageProcessor']]]
];
